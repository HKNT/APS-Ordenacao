
public class Iniciar {

	public static void main(String[] args) 
	{
		MenuPrincipal jj = new MenuPrincipal();
		jj.setVisible(true);
	}
}
